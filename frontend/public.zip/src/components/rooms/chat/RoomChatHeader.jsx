import { useNavigate } from "react-router";
import { useRoomStore } from "../../../store/useRoomStore";
import { useAuthStore } from "../../../store/useAuthStore";

export default function RoomChatHeader({ onToggleMembers }) {
  const navigate = useNavigate();
  const { activeRoom } = useRoomStore();
  const { onlineUsers } = useAuthStore();

  if (!activeRoom) return null;

  const onlineMembersCount = activeRoom.members?.filter((m) =>
    onlineUsers.includes(m._id || m)
  ).length ?? 0;

  const handleBack = () => {
    navigate("/");
  };

  return (
    <div className="flex items-center justify-between px-4 py-3 border-b border-white/5 bg-[#111113] flex-shrink-0">

      {/* Left: back + room info */}
      <div className="flex items-center gap-3">
        <button
          onClick={handleBack}
          className="w-8 h-8 flex items-center justify-center rounded-lg text-zinc-500 hover:text-white hover:bg-white/5 transition-colors"
        >
          ←
        </button>

        {/* Room emoji + name */}
        <div
          className="w-9 h-9 rounded-xl flex items-center justify-center text-xl flex-shrink-0"
          style={{ background: `${activeRoom.accentColor || "#4f8ef7"}20` }}
        >
          {activeRoom.emoji || "💬"}
        </div>

        <div>
          <h2 className="text-white font-bold text-sm leading-tight">{activeRoom.name}</h2>
          <p className="text-zinc-500 text-xs">
            {activeRoom.members?.length ?? 0} members · {onlineMembersCount} online
          </p>
        </div>
      </div>

      {/* Right: members toggle */}
      <button
        onClick={onToggleMembers}
        className="flex items-center gap-2 px-3 py-1.5 rounded-lg text-zinc-400 hover:text-white hover:bg-white/5 transition-colors text-sm"
      >
        <span>👥</span>
        <span className="hidden sm:inline text-xs font-medium">Members</span>
      </button>
    </div>
  );
}