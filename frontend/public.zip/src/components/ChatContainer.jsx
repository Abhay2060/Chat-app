import { useEffect, useRef, useState } from "react";
import { useAuthStore } from "../store/useAuthStore";
import { useChatStore } from "../store/useChatStore";
import ChatHeader from "./ChatHeader";
import NoChatHistoryPlaceholder from "./NoChatHistoryPlaceholder";
import MessageInput from "./MessageInput";
import MessagesLoadingSkeleton from "./MessagesLoadingSkeleton";
import EmojiPicker from "emoji-picker-react";

const QUICK_EMOJIS = ["👍", "❤️", "😂", "😮", "😢", "😡"];

function ChatContainer() {
  const {
    selectedUser,
    getMessagesByUserId,
    messages,
    isMessagesLoading,
    subscribeToMessages,
    unsubscribeFromMessages,
    reactToMessage,
  } = useChatStore();
  const { authUser } = useAuthStore();
  const messageEndRef = useRef(null);
  const [hoveredMsgId, setHoveredMsgId] = useState(null);
  const [expandedPickerMsgId, setExpandedPickerMsgId] = useState(null);
  const hoverTimeoutRef = useRef(null);

  useEffect(() => {
    getMessagesByUserId(selectedUser._id);
    subscribeToMessages();
    return () => unsubscribeFromMessages();
  }, [selectedUser, getMessagesByUserId, subscribeToMessages, unsubscribeFromMessages]);

  useEffect(() => {
    if (messageEndRef.current) {
      messageEndRef.current.scrollIntoView({ behavior: "smooth" });
    }
  }, [messages]);

  useEffect(() => {
    const handleClickOutside = (e) => {
      if (!e.target.closest(".reaction-zone")) {
        setExpandedPickerMsgId(null);
        setHoveredMsgId(null);
      }
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  const handleMouseEnter = (msgId) => {
    if (hoverTimeoutRef.current) clearTimeout(hoverTimeoutRef.current);
    setHoveredMsgId(msgId);
  };

  const handleMouseLeave = () => {
    hoverTimeoutRef.current = setTimeout(() => {
      if (!expandedPickerMsgId) {
        setHoveredMsgId(null);
      }
    }, 300);
  };

  return (
    <>
      <ChatHeader />
      <div className="flex-1 px-6 overflow-y-auto py-8">
        {messages.length > 0 && !isMessagesLoading ? (
          <div className="max-w-3xl mx-auto space-y-6 pb-96">
            {messages.map((msg) => {
              const isMyMessage = msg.senderId === authUser._id;
              const reactions = msg.reactions || {};

              return (
                <div
                  key={msg._id}
                  className={`chat ${isMyMessage ? "chat-end" : "chat-start"}`}
                >
                  <div
                    className="relative reaction-zone"
                    onMouseEnter={() => handleMouseEnter(msg._id)}
                    onMouseLeave={handleMouseLeave}
                  >
                    {/* Quick Reaction Bar - BELOW the bubble */}
                    {hoveredMsgId === msg._id && (
                      <div
                        className={`absolute top-full mt-2 flex items-center gap-1 bg-slate-900 
                        border border-slate-700 rounded-full px-2 py-1 shadow-xl z-10
                        ${isMyMessage ? "right-0" : "left-0"}`}
                        onMouseEnter={() => {
                          if (hoverTimeoutRef.current) clearTimeout(hoverTimeoutRef.current);
                        }}
                      >
                        {QUICK_EMOJIS.map((emoji) => (
                          <button
                            key={emoji}
                            onClick={() => reactToMessage(msg._id, emoji)}
                            className="hover:scale-125 transition-transform text-base leading-none"
                          >
                            {emoji}
                          </button>
                        ))}
                        <button
                          onClick={() =>
                            setExpandedPickerMsgId(
                              expandedPickerMsgId === msg._id ? null : msg._id
                            )
                          }
                          className="text-slate-400 hover:text-white transition-colors text-lg font-bold px-1 leading-none"
                        >
                          +
                        </button>
                      </div>
                    )}

                    {/* Full Emoji Picker - below the quick bar */}
                    {expandedPickerMsgId === msg._id && (
                      <div
                        className={`absolute z-20 ${isMyMessage ? "right-0" : "left-0"}`}
                        style={{ top: "160%" }}
                        onMouseEnter={() => {
                          if (hoverTimeoutRef.current) clearTimeout(hoverTimeoutRef.current);
                        }}
                      >
                        <EmojiPicker
                          theme="dark"
                          height={350}
                          width={300}
                          onEmojiClick={(emojiData) => {
                            reactToMessage(msg._id, emojiData.emoji);
                            setExpandedPickerMsgId(null);
                            setHoveredMsgId(null);
                          }}
                        />
                      </div>
                    )}

                    {/* Message Bubble */}
                    <div
                      className={`chat-bubble relative ${
                        isMyMessage
                          ? "bg-cyan-600 text-white"
                          : "bg-slate-800 text-slate-200"
                      }`}
                    >
                      {msg.image && (
                        <img
                          src={msg.image}
                          alt="Shared"
                          className="rounded-lg h-48 object-cover"
                        />
                      )}
                      {msg.text && <p className="mt-2">{msg.text}</p>}
                      <p className="text-xs mt-1 opacity-75">
                        {new Date(msg.createdAt).toLocaleTimeString(undefined, {
                          hour: "2-digit",
                          minute: "2-digit",
                        })}
                      </p>
                    </div>

                    {/* Reactions Display */}
                    {Object.keys(reactions).length > 0 && (
                      <div
                        className={`flex flex-wrap gap-1 mt-1 ${
                          isMyMessage ? "justify-end" : "justify-start"
                        }`}
                      >
                        {Object.entries(reactions).map(([emoji, users]) =>
                          users.length > 0 ? (
                            <button
                              key={emoji}
                              onClick={() => reactToMessage(msg._id, emoji)}
                              className={`text-xs flex items-center gap-1 rounded-full px-2 py-0.5 
                              border transition-colors
                              ${
                                users.includes(authUser._id)
                                  ? "bg-cyan-500/20 border-cyan-500 text-cyan-300"
                                  : "bg-slate-800 border-slate-700 text-slate-300 hover:border-slate-500"
                              }`}
                            >
                              {emoji} <span>{users.length}</span>
                            </button>
                          ) : null
                        )}
                      </div>
                    )}
                  </div>
                </div>
              );
            })}
            <div ref={messageEndRef} />
          </div>
        ) : isMessagesLoading ? (
          <MessagesLoadingSkeleton />
        ) : (
          <NoChatHistoryPlaceholder name={selectedUser.fullName} />
        )}
      </div>
      <MessageInput />
    </>
  );
}

export default ChatContainer;