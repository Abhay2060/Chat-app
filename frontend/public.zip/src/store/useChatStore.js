import { create } from "zustand";
import { axiosInstance } from "../lib/axios";
import toast from "react-hot-toast";
import { useAuthStore } from "./useAuthStore";

export const useRoomStore = create((set, get) => ({
  rooms:       [],
  myRooms:     [],
  activeRoom:  null,
  roomMessages: [],
  roomMembers:  [],

  isRoomsLoading:        false,
  isRoomMessagesLoading: false,
  isCreatingRoom:        false,
  isJoiningRoom:         false,

  // ── Room Fetching ────────────────────────────────────────────────────────────

  getAllRooms: async () => {
    set({ isRoomsLoading: true });
    try {
      const res = await axiosInstance.get("/rooms");
      set({ rooms: res.data });
    } catch (error) {
      toast.error(error.response?.data?.message || "Failed to load rooms");
    } finally {
      set({ isRoomsLoading: false });
    }
  },

  getMyRooms: async () => {
    set({ isRoomsLoading: true });
    try {
      const res = await axiosInstance.get("/rooms/my-rooms");
      set({ myRooms: res.data });
    } catch (error) {
      toast.error(error.response?.data?.message || "Failed to load your rooms");
    } finally {
      set({ isRoomsLoading: false });
    }
  },

  // ── Active Room ──────────────────────────────────────────────────────────────

  setActiveRoom: (room) => {
    set({ activeRoom: room, roomMessages: [], roomMembers: [] });
  },

  clearActiveRoom: () => set({ activeRoom: null, roomMessages: [], roomMembers: [] }),

  // ── Messages ────────────────────────────────────────────────────────────────

  getRoomMessages: async (roomId) => {
    set({ isRoomMessagesLoading: true });
    try {
      const res = await axiosInstance.get(`/rooms/${roomId}/messages`);
      set({ roomMessages: res.data });
    } catch (error) {
      toast.error(error.response?.data?.message || "Failed to load messages");
    } finally {
      set({ isRoomMessagesLoading: false });
    }
  },

  getRoomMembers: async (roomId) => {
    try {
      const res = await axiosInstance.get(`/rooms/${roomId}/members`);
      set({ roomMembers: res.data });
    } catch (error) {
      toast.error(error.response?.data?.message || "Failed to load members");
    }
  },

  // ── Room CRUD ────────────────────────────────────────────────────────────────

  createRoom: async (roomData) => {
    set({ isCreatingRoom: true });
    try {
      const res = await axiosInstance.post("/rooms/create", roomData);
      set({ rooms: [...get().rooms, res.data], myRooms: [...get().myRooms, res.data] });
      toast.success(`Room "${res.data.name}" created!`);
      return res.data;
    } catch (error) {
      toast.error(error.response?.data?.message || "Failed to create room");
      return null;
    } finally {
      set({ isCreatingRoom: false });
    }
  },

  updateRoom: async (roomId, data) => {
    try {
      const res = await axiosInstance.put(`/rooms/${roomId}`, data);
      set({
        rooms:   get().rooms.map((r)   => r._id === roomId ? res.data : r),
        myRooms: get().myRooms.map((r) => r._id === roomId ? res.data : r),
      });
      toast.success("Room updated!");
      return res.data;
    } catch (error) {
      toast.error(error.response?.data?.message || "Failed to update room");
      return null;
    }
  },

  deleteRoom: async (roomId) => {
    try {
      await axiosInstance.delete(`/rooms/${roomId}`);
      set({
        rooms:   get().rooms.filter((r)   => r._id !== roomId),
        myRooms: get().myRooms.filter((r) => r._id !== roomId),
      });
      if (get().activeRoom?._id === roomId) get().clearActiveRoom();
      toast.success("Room deleted");
    } catch (error) {
      toast.error(error.response?.data?.message || "Failed to delete room");
    }
  },

  // ── Membership ───────────────────────────────────────────────────────────────

  joinRoom: async (roomId) => {
    set({ isJoiningRoom: true });
    try {
      const res = await axiosInstance.post(`/rooms/${roomId}/join`);
      const alreadyIn = get().myRooms.some((r) => r._id === roomId);
      if (!alreadyIn) set({ myRooms: [...get().myRooms, res.data] });
      set({ rooms: get().rooms.map((r) => r._id === roomId ? res.data : r) });
      return res.data;
    } catch (error) {
      toast.error(error.response?.data?.message || "Failed to join room");
      return null;
    } finally {
      set({ isJoiningRoom: false });
    }
  },

  leaveRoom: async (roomId) => {
    try {
      await axiosInstance.post(`/rooms/${roomId}/leave`);
      set({ myRooms: get().myRooms.filter((r) => r._id !== roomId) });
      if (get().activeRoom?._id === roomId) get().clearActiveRoom();
      toast.success("Left the room");
    } catch (error) {
      toast.error(error.response?.data?.message || "Failed to leave room");
    }
  },

  // ── Send Message ─────────────────────────────────────────────────────────────

  sendRoomMessage: async (messageData) => {
    const { activeRoom, roomMessages } = get();
    const { authUser } = useAuthStore.getState();
    if (!activeRoom) return;

    // Optimistic update — same pattern as useChatStore
    const tempId = `temp-${Date.now()}`;
    const optimisticMessage = {
      _id:       tempId,
      senderId:  { _id: authUser._id, fullName: authUser.fullName, profilePic: authUser.profilePic },
      roomId:    activeRoom._id,
      text:      messageData.text,
      image:     messageData.image,
      reactions: {},
      createdAt: new Date().toISOString(),
      isOptimistic: true,
    };

    set({ roomMessages: [...roomMessages, optimisticMessage] });

    try {
      const res = await axiosInstance.post(`/rooms/${activeRoom._id}/messages/send`, messageData);
      set({
        roomMessages: get().roomMessages.map((msg) =>
          msg._id === tempId ? res.data : msg
        ),
      });
    } catch (error) {
      set({ roomMessages });
      toast.error(error.response?.data?.message || "Failed to send message");
    }
  },

  // ── React to Message ─────────────────────────────────────────────────────────
  // Same logic as useChatStore.reactToMessage

  reactToRoomMessage: async (messageId, emoji) => {
    try {
      const userId = useAuthStore.getState().authUser._id;
      const { activeRoom } = get();

      const updatedMessages = get().roomMessages.map((msg) => {
        if (msg._id !== messageId) return msg;
        const reactions = JSON.parse(JSON.stringify(msg.reactions || {}));

        let previousEmoji = null;
        for (const [key, users] of Object.entries(reactions)) {
          if (users.includes(userId)) { previousEmoji = key; break; }
        }
        for (const key of Object.keys(reactions)) {
          reactions[key] = reactions[key].filter((id) => id !== userId);
        }
        if (previousEmoji !== emoji) {
          reactions[emoji] = [...(reactions[emoji] || []), userId];
        }
        return { ...msg, reactions };
      });

      set({ roomMessages: updatedMessages });

      const res = await axiosInstance.post(
        `/rooms/${activeRoom._id}/messages/${messageId}/react`,
        { emoji }
      );

      set({
        roomMessages: get().roomMessages.map((msg) =>
          msg._id === messageId ? { ...msg, reactions: res.data.reactions } : msg
        ),
      });
    } catch (error) {
      toast.error("Failed to react");
    }
  },

  // ── Socket Subscriptions ─────────────────────────────────────────────────────

  subscribeToRoomMessages: () => {
    const { activeRoom } = get();
    if (!activeRoom) return;

    const socket = useAuthStore.getState().socket;

    socket.on("newRoomMessage", (newMessage) => {
      if (newMessage.roomId !== activeRoom._id &&
          newMessage.receiverId !== activeRoom._id) return;
      set({ roomMessages: [...get().roomMessages, newMessage] });
    });

    socket.on("roomMessageReacted", ({ messageId, reactions }) => {
      set({
        roomMessages: get().roomMessages.map((msg) =>
          msg._id === messageId ? { ...msg, reactions } : msg
        ),
      });
    });

    socket.on("roomMemberJoined", ({ roomId, user }) => {
      if (roomId !== activeRoom._id) return;
      const alreadyIn = get().roomMembers.some((m) => m._id === user._id);
      if (!alreadyIn) set({ roomMembers: [...get().roomMembers, user] });
    });

    socket.on("roomMemberLeft", ({ roomId, userId }) => {
      if (roomId !== activeRoom._id) return;
      set({ roomMembers: get().roomMembers.filter((m) => m._id !== userId) });
    });

    socket.on("roomUpdated", (updatedRoom) => {
      if (updatedRoom._id !== activeRoom._id) return;
      set({ activeRoom: updatedRoom });
    });

    socket.on("roomDeleted", ({ roomId }) => {
      if (roomId !== activeRoom._id) return;
      toast.error("This room has been deleted");
      get().clearActiveRoom();
    });
  },

  unsubscribeFromRoomMessages: () => {
    const socket = useAuthStore.getState().socket;
    socket.off("newRoomMessage");
    socket.off("roomMessageReacted");
    socket.off("roomMemberJoined");
    socket.off("roomMemberLeft");
    socket.off("roomUpdated");
    socket.off("roomDeleted");
  },
}));